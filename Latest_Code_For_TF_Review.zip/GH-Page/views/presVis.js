PresVis = function(_parentElement, _data, _eventHandler){
    this.parentElement = _parentElement;
    this.data = _data;
    this.eventHandler = _eventHandler;
    this.displayData = [];

    this.parentID = '#' + this.parentElement.attr('id');

    // TODO: define all "constants" here
    this.margin = {top: 20, right: 40, bottom: 20, left: 40}
    this.width = 
      $(this.parentID).width() - this.margin.left - this.margin.right,
    this.height = 750 - this.margin.top - this.margin.bottom;

    this.initVis();
}

PresVis.prototype.initVis = function() {
  var that = this;
  
  
  this.dateFormatter = d3.time.format("%Y-%m-%d");


  this.graph = {nodes:[]};
  this.republicans = [];
  this.democrats = [];


  this.xScaleDem = d3.scale.linear()
                  .range([0, 2 * that.width / 5]);
  
  this.xScaleRep = d3.scale.linear()
                  .range([3 * that.width / 5, that.width]);
  
  this.xScaleOrdinal = d3.scale.ordinal()
                      .rangePoints([0, that.width]);

  this.xAxis = d3.svg.axis()
                 .orient('bottom')
                 .ticks(2);
  
  this.svg = this.parentElement 
                 .append('svg')
                 .attr({
                   'width': 
                      that.width + this.margin.left + this.margin.right,
                   'height': 
                      that.height + this.margin.bottom
                 });
  
  this.node = this.svg.selectAll('.node');
  
  this.wrangleData();
  
  
  this.updateVis();
  
}

PresVis.prototype.wrangleData = function() {
  var that = this;

  this.displayData = this.filterAndAggregate();
  this.graph.nodes = this.displayData;
  this.filterByParty();
}

PresVis.prototype.updateVis = function() {
  var that = this;

  this.xScaleDem.domain(this.displayData.map(function(d) {
    return d.bio.age;
  }));
  
  this.xScaleRep.domain(this.displayData.map(function(d) {
    return d.bio.age;
  }));

  this.xScaleOrdinal.domain(this.displayData.map(function(d) {
    return d.name.first;
  }));

  
  this.node.data(that.graph.nodes)
           .enter()
           .append('g')
           .attr('class', 'node')
           .attr('id', function(d) { return d.name.first;})
           .attr('transform', function(d) {
             return 'translate(' + that.xScaleOrdinal(d.name.first) + ',0)';
           });

  this.svg.selectAll('g').select(function(d, i) {
    var localThat = this;
    var importSVG = d3.xml(d.bio.picture, 'image/svg+xml', function(xml) {
      if (xml !== undefined) {
        localThat.appendChild(xml.documentElement);
        d3.select(localThat).select('svg').select('g').attr('transform', 'scale(0.1)');
      } else {
        console.log('picture is undefined');
      }
    });
    return importSVG;
  });
  
  this.svg.append('g')
          .attr('transform', 'translate(0,' + that.height + ')')
          .call(that.xAxis);

}

PresVis.prototype.filterAndAggregate = function() {
  var that = this;
  var hasPic = this.data.filter(function(a) {
   return a.bio.picture !== ""; 
  });
  var hasPicAndAge;
  
  var calculateAge = function(d) {
    var dateObj = that.dateFormatter.parse(d.bio.birthday);
    var currentTime = new Date();
    var ageInMS = +currentTime - +dateObj;
    var convertToYear = function(time) {
      var conversionFactor = 1000 * 3600 * 24 * 365;
        return Math.floor(time / conversionFactor);
    }
    return convertToYear(ageInMS);
  }
  
  hasPicAndAge = hasPic.map(function(pres) {
    pres.bio.age = calculateAge(pres);
    return pres;
  });
    
  return hasPicAndAge;
}

PresVis.prototype.filterByParty = function() {
  var that = this;

  this.republicans = this.displayData.filter(function(d) {
    return d.bio.party === 'Republican';
  });

  this.democrats = this.displayData.filter(function(d) {
    return d.bio.party === 'Democrat';
  });
}
  





