SinceVis = function(_parentElement, _data, _eventHandler){
    this.parentElement = _parentElement;
    this.data = _data;
    this.eventHandler = _eventHandler;
    this.displayData = [];
    this.embed = ($.embedly);
    this.embed.defaults.key = 'c2c6207708ea43a686cca0325ec73e87';

    this.parentID = '#' + this.parentElement.attr('id');

    // TODO: define all "constants" here
    this.margin = {top: 20, right: 40, bottom: 20, left: 40};
    this.width = 
      $(this.parentID).width() - this.margin.left - this.margin.right;
    this.height = 750 - this.margin.top - this.margin.bottom;

    this.initVis();
}

SinceVis.prototype.initVis = function() {
  var that = this;
  
  this.dateFormatter = d3.time.format("%Y-%m-%d");

  this.xTimeScale = d3.time.scale()
                      .range([that.margin.left, that.width + that.margin.left]);
  
  this.yOrdScale = d3.scale.ordinal()
                     .rangeRoundBands([that.height/2, that.margin.top]);
  
  this.xTimeAxis = d3.svg.axis()
                     .scale(that.xTimeScale)
                     .ticks(6)
                     .orient('bottom');
  
  this.colors = d3.scale.category20();
                  
  
  this.yOrdAxis = d3.svg.axis()
                     .scale(that.yOrdScale)
                     .orient('right');
  
  this.brush = d3.svg.brush()
                 .x(that.xTimeScale)
                 .extent([new Date(2014, 12, 16), new Date (2015, 5, 5)])
                 .on('brush', function() {
                  var value = that.brush.extent();
                  console.log('value', value);

                  var brushedDatum = this.displayData.filter(function(d) {
                    return +d["pub_date"] === value[1];
                  });

                  d3.select('.embedly-element')
                    .select('a')
                    .attr('href', brushed.datum["web_url"]);
                 });
                   
  this.svg = this.parentElement 
                 .append('svg')
                 .attr({
                   'width': 
                      that.width + this.margin.left + this.margin.right,
                   'height': 
                      that.height + this.margin.bottom
                 });

  this.svg.append('g')
      .attr('class', 'xTime axis')
      .attr('transform', 'translate(0,' + (2 * this.height/3) + ')');
  
  this.wrangleData();
  
  this.updateVis();
  
}

SinceVis.prototype.wrangleData = function() {
  this.displayData = this.filterDuplicates();
  console.log(this.displayData);
}

SinceVis.prototype.updateVis = function() {
  var that = this;

  this.xTimeScale.domain(that.displayData.map(function(d) {
    return d["pub_date"];
  }));
  

  this.yOrdScale.domain(that.displayData.map(function(d,i) {
    return i;
  }));

  this.colors.domain(this.displayData.map(function(d) {
    return d["pub_date"];
  }));


  
  // updates axis
  this.svg.select(".xTime.axis")
      .call(that.xTimeAxis);
  
  
  // updates graph
  var circles = 
    this.svg.selectAll('.thawEvents.circles')
        .data(that.displayData)  
  
  circles 
    .enter()
    .append('g')
    .attr('class', 'thawEvents')
    .append("circle")
    .attr({
      "class": "circles",
      "cx": function(d, i) {return that.xTimeScale(d["pub_date"]);},
      "cy": function(d, i) { return that.yOrdScale(i);},
      "stroke": "black",
      "fill": function(d, i) {return that.colors(d["pub_date"]);},
      "r": 15 
    });
  
  circles 
    .exit()
    .remove()
  
  var brushSelection = this.svg.append("g")
    .attr("class", "brush")
    .call(that.brush);

  brushSelection.selectAll("rect")
    .attr("height", (2 * that.height/3));

}

SinceVis.prototype.filterDuplicates = function() {
  var that = this;
  var noDuplicates = this.data.filter(function(item, pos) {
    return that.data.indexOf(item) == pos;
  });

  console.log('no',noDuplicates);
  return noDuplicates;
}

